import 'package:flutter/material.dart';
import 'views/my_app.dart';

void main() {
  runApp(MyApp());
}
