class Names {
  final String firstName;
  final String lastName;
  Names({
    this.firstName,
    this.lastName,
  });
}
