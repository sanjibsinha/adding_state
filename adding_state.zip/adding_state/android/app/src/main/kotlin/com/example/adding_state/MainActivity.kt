package com.example.adding_state

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
